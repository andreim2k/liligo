=======
Credits
=======

Development Lead
----------------

* Henrik Blidh <henrik.blidh@nedomkull.com>

Development Team / Collaborators
--------------------------------

* David Lechner <david@pybricks.com>

Contributors
------------

* Chad Spensky <chad@allthenticate.net>
* Bernie Conrad <bernie@allthenticate.net>
* Jonathan Soto <jsotogaviard@alum.mit.edu>
* Kyle J. Williams <kyle@kjwill.tech>
* Edward Betts <edward@4angle.com>
* Robbe Gaeremynck <robbe.gaeremynck@outlook.com>
* David Johansen <davejohansen@gmail.com>
* JP Hutchins <jphutchins@gmail.com>
* Bram Duvigneau <bram@bramd.nl>

Sponsors
--------

* Nabu Casa <https://www.nabucasa.com/>
